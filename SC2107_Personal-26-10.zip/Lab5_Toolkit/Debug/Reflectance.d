# FIXED

Reflectance.obj: C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/SC2107_Lab5_Toolkit/inc/Reflectance.c
Reflectance.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h
Reflectance.obj: C:/ti/ccsv7/ccs_base/arm/include/msp432.h
Reflectance.obj: C:/ti/ccsv7/ccs_base/arm/include/msp432p401r.h
Reflectance.obj: C:/ti/ccsv7/ccs_base/arm/include/msp_compatibility.h
Reflectance.obj: C:/ti/ccsv7/ccs_base/arm/include/CMSIS/cmsis_ccs.h
Reflectance.obj: C:/ti/ccsv7/ccs_base/arm/include/msp432p401r_classic.h
Reflectance.obj: C:/ti/ccsv7/ccs_base/arm/include/CMSIS/core_cm4.h
Reflectance.obj: C:/ti/ccsv7/ccs_base/arm/include/CMSIS/cmsis_compiler.h
Reflectance.obj: C:/ti/ccsv7/ccs_base/arm/include/system_msp432p401r.h
Reflectance.obj: C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/SC2107_Lab5_Toolkit/inc/../inc/Clock.h

C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/SC2107_Lab5_Toolkit/inc/Reflectance.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h: 
C:/ti/ccsv7/ccs_base/arm/include/msp432.h: 
C:/ti/ccsv7/ccs_base/arm/include/msp432p401r.h: 
C:/ti/ccsv7/ccs_base/arm/include/msp_compatibility.h: 
C:/ti/ccsv7/ccs_base/arm/include/CMSIS/cmsis_ccs.h: 
C:/ti/ccsv7/ccs_base/arm/include/msp432p401r_classic.h: 
C:/ti/ccsv7/ccs_base/arm/include/CMSIS/core_cm4.h: 
C:/ti/ccsv7/ccs_base/arm/include/CMSIS/cmsis_compiler.h: 
C:/ti/ccsv7/ccs_base/arm/include/system_msp432p401r.h: 
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/SC2107_Lab5_Toolkit/inc/../inc/Clock.h: 
