# FIXED

TExaS.obj: C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/TExaS.c
TExaS.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h
TExaS.obj: C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/../inc/CortexM.h
TExaS.obj: C:/ti/ccsv7/ccs_base/arm/include/msp.h
TExaS.obj: C:/ti/ccsv7/ccs_base/arm/include/msp432p401r.h
TExaS.obj: C:/ti/ccsv7/ccs_base/arm/include/msp_compatibility.h
TExaS.obj: C:/ti/ccsv7/ccs_base/arm/include/CMSIS/cmsis_ccs.h
TExaS.obj: C:/ti/ccsv7/ccs_base/arm/include/msp432p401r_classic.h
TExaS.obj: C:/ti/ccsv7/ccs_base/arm/include/CMSIS/core_cm4.h
TExaS.obj: C:/ti/ccsv7/ccs_base/arm/include/CMSIS/cmsis_compiler.h
TExaS.obj: C:/ti/ccsv7/ccs_base/arm/include/system_msp432p401r.h
TExaS.obj: C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/../inc/TExaS.h

C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/TExaS.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h: 
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/../inc/CortexM.h: 
C:/ti/ccsv7/ccs_base/arm/include/msp.h: 
C:/ti/ccsv7/ccs_base/arm/include/msp432p401r.h: 
C:/ti/ccsv7/ccs_base/arm/include/msp_compatibility.h: 
C:/ti/ccsv7/ccs_base/arm/include/CMSIS/cmsis_ccs.h: 
C:/ti/ccsv7/ccs_base/arm/include/msp432p401r_classic.h: 
C:/ti/ccsv7/ccs_base/arm/include/CMSIS/core_cm4.h: 
C:/ti/ccsv7/ccs_base/arm/include/CMSIS/cmsis_compiler.h: 
C:/ti/ccsv7/ccs_base/arm/include/system_msp432p401r.h: 
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/../inc/TExaS.h: 
