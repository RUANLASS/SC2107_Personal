################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../msp432p401r.cmd 

C_SRCS += \
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/Bump.c \
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/Clock.c \
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/CortexM.c \
../Lab3_Timersmain.c \
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/LaunchPad.c \
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/Motor.c \
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/PWM.c \
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/Reflectance.c \
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/TExaS.c \
C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/TimerA1.c \
../startup_msp432p401r_ccs.c \
../system_msp432p401r.c 

C_DEPS += \
./Bump.d \
./Clock.d \
./CortexM.d \
./Lab3_Timersmain.d \
./LaunchPad.d \
./Motor.d \
./PWM.d \
./Reflectance.d \
./TExaS.d \
./TimerA1.d \
./startup_msp432p401r_ccs.d \
./system_msp432p401r.d 

OBJS += \
./Bump.obj \
./Clock.obj \
./CortexM.obj \
./Lab3_Timersmain.obj \
./LaunchPad.obj \
./Motor.obj \
./PWM.obj \
./Reflectance.obj \
./TExaS.obj \
./TimerA1.obj \
./startup_msp432p401r_ccs.obj \
./system_msp432p401r.obj 

OBJS__QUOTED += \
"Bump.obj" \
"Clock.obj" \
"CortexM.obj" \
"Lab3_Timersmain.obj" \
"LaunchPad.obj" \
"Motor.obj" \
"PWM.obj" \
"Reflectance.obj" \
"TExaS.obj" \
"TimerA1.obj" \
"startup_msp432p401r_ccs.obj" \
"system_msp432p401r.obj" 

C_DEPS__QUOTED += \
"Bump.d" \
"Clock.d" \
"CortexM.d" \
"Lab3_Timersmain.d" \
"LaunchPad.d" \
"Motor.d" \
"PWM.d" \
"Reflectance.d" \
"TExaS.d" \
"TimerA1.d" \
"startup_msp432p401r_ccs.d" \
"system_msp432p401r.d" 

C_SRCS__QUOTED += \
"C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/Bump.c" \
"C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/Clock.c" \
"C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/CortexM.c" \
"../Lab3_Timersmain.c" \
"C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/LaunchPad.c" \
"C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/Motor.c" \
"C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/PWM.c" \
"C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/Reflectance.c" \
"C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/TExaS.c" \
"C:/Users/LAKSHYA002/Downloads/SC2107_Personal-main/SC2107_Personal-main/inc/TimerA1.c" \
"../startup_msp432p401r_ccs.c" \
"../system_msp432p401r.c" 


